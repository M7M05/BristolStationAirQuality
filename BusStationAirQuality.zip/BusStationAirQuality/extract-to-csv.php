<?php
date_default_timezone_set('GMT');
ini_set('auto_detect_line_endings', TRUE);
$input_file = fopen('air-quality-data-2003-2022.csv', 'r');
if (!$input_file) {
    die('Failed to open input file');
}
$output_files = array(
    '188' => fopen('data-188.csv', 'w'),
    '203' => fopen('data-203.csv', 'w'),
    '206' => fopen('data-206.csv', 'w'),
    '209' => fopen('data-209.csv', 'w'),
    '213' => fopen('data-213.csv', 'w'),
    '215' => fopen('data-215.csv', 'w'),
    '228' => fopen('data-228.csv', 'w'),
    '270' => fopen('data-270.csv', 'w'),
    '271' => fopen('data-271.csv', 'w'),
    '375' => fopen('data-375.csv', 'w'),
    '395' => fopen('data-395.csv', 'w'),
    '452' => fopen('data-452.csv', 'w'),
    '447' => fopen('data-447.csv', 'w'),
    '459' => fopen('data-459.csv', 'w'),
    '463' => fopen('data-463.csv', 'w'),
    '481' => fopen('data-481.csv', 'w'),
    '500' => fopen('data-500.csv', 'w'),
    '501' => fopen('data-501.csv', 'w'),
    '672' => fopen('data-672.csv', 'w')
);
foreach ($output_files as $siteID => $output_file) {
    if (!$output_file) {
        continue;
    }
    fputcsv($output_file, array(
        'siteID', 'ts', 'NOx', 'NO2', 'NO', 'PM10', 'NVPM10', 'VPM10', 'NVPM2.5', 'PM2.5', 'VPM2.5', 'CO', 'O3', 'SO2', 'location', 'lat', 'long'
    ));
}
while (($line = fgets($input_file)) !== false) {
    $data = str_getcsv($line, ';');
    if ($data[1] === '' && $data[11] === '') {
        continue;
    }
    $output_data = array(
        $data[4],
        strtotime($data[0]),
        $data[1],
        $data[2],
        $data[3],
        $data[5],
        $data[6],
        $data[7],
        $data[8],
        $data[9],
        $data[10],
        $data[11],
        $data[12],
        $data[13],
        $data[17],
        explode(', ', $data[18])[0],
        explode(', ', $data[18])[1]
    );
    foreach ($output_files as $siteID => $output_file) {
        if (!isset($output_files[$siteID])) {
            continue;
        }
        if (!$output_file) {
            continue;
        }
        if ($output_data[0] == $siteID) {
            fputcsv($output_file, $output_data);
        }
    }
}
fclose($input_file);
foreach ($output_files as $output_file) {
    fclose($output_file);
}