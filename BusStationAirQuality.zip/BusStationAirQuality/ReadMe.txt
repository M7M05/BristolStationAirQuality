<<Instructions For Use>>

To test the PHP functionality:

First, extract the data zipped as an air-quality-data file.

Then run the extract to CSV PHP.

Thirdly, normalise this data to XML using the provided Normalise PHP script.

Once these processes are completed, you can view the station locations using the Map script or edit the chart script to visualise the different station data.