<?php
$file = 'data-209.xml';       //vvv link is relitive to system location & the station data you wish to view vvv
$xml = simplexml_load_file('http://localhost/BusStationAirQuality/data-209.xml');
$dataLineChart = [];
$dataScatterChart = [];
foreach ($xml->rec as $rec) {
    $timestamp = (int)$rec['ts'];
    $time = ($timestamp !== 0) ? gmdate("H:i", $timestamp) : 'N/A';
    $month = ($timestamp !== 0) ? gmdate("F", $timestamp) : 'N/A';
    $dataLineChart[] = [$time, (float)$rec['nox'], (float)$rec['no2'], (float)$rec['no']];
    $dataScatterChart[] = [$month, (float)$rec['nox']];
}
?>
<!DOCTYPE html>
<html>
<head>
  <title>Chart</title>
  <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
  <script type="text/javascript">
    google.charts.load('current', {'packages':['corechart']});
    google.charts.setOnLoadCallback(drawLineChart);
    google.charts.setOnLoadCallback(drawScatterChart);
    function drawLineChart() {
      var data = new google.visualization.DataTable();
      data.addColumn('string', 'Time');
      data.addColumn('number', 'NOx');
      data.addColumn('number', 'NO2');
      data.addColumn('number', 'NO');
      data.addRows(<?php echo json_encode($dataLineChart); ?>);
      var options = {
        title: 'NOx, NO, and NO2 Levels by Time of Day',
        curveType: 'function',
        legend: { position: 'bottom' },
        vAxis: {
          title: 'Concentration (ppb)'
        },
        hAxis: {
          title: 'Time of Day'
        }
      };
      var chart = new google.visualization.LineChart(document.getElementById('linechart'));
      chart.draw(data, options);
    }
    function drawScatterChart() {
      var data = new google.visualization.DataTable();
      data.addColumn('string', 'Month');
      data.addColumn('number', 'NOx');
      data.addRows(<?php echo json_encode($dataScatterChart); ?>);
      var options = {
        title: 'NOx Levels by Month',
        hAxis: {
          title: 'Month'
        },
        vAxis: {
          title: 'Concentration (ppb)'
        },
        legend: { position: 'none' }
      };
      var chart = new google.visualization.ScatterChart(document.getElementById('scatterchart'));
      chart.draw(data, options);
    }
  </script>
</head>
<body>
  <div id="linechart" style="width: 100%; height: 500px"></div>
  <div id="scatterchart" style="width: 100%; height: 500px"></div>
</body>
</html>