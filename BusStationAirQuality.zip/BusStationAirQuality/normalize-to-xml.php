<?php
date_default_timezone_set('GMT');
ini_set('auto_detect_line_endings', TRUE);
$output_file_paths = array(
    'data-188.csv' => 'data-188.xml',
    'data-203.csv' => 'data-203.xml',
    'data-206.csv' => 'data-206.xml',
    'data-209.csv' => 'data-209.xml',
    'data-213.csv' => 'data-213.xml',
    'data-215.csv' => 'data-215.xml',
    'data-228.csv' => 'data-228.xml',
    'data-270.csv' => 'data-270.xml',
    'data-271.csv' => 'data-271.xml',
    'data-375.csv' => 'data-375.xml',
    'data-395.csv' => 'data-395.xml',
    'data-452.csv' => 'data-452.xml',
    'data-447.csv' => 'data-447.xml',
    'data-459.csv' => 'data-459.xml',
    'data-463.csv' => 'data-463.xml',
    'data-481.csv' => 'data-481.xml',
    'data-500.csv' => 'data-500.xml',
    'data-501.csv' => 'data-501.xml',
    'data-672.csv' => 'data-672.xml'
);
foreach ($output_file_paths as $input_path => $output_path) {
    $input_file = fopen($input_path, 'r');
    $output_file = fopen($output_path, 'w');
    fwrite($output_file, "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
    $station_id = substr($input_path, 5, 3);
    $header = fgetcsv($input_file);
    $location_index = array_search('location', $header);
    $lat_index = array_search('lat', $header);
    $long_index = array_search('long', $header);
    $first_row = fgetcsv($input_file);
    $station_name = $first_row[$location_index];
    $station_geocode = $first_row[$lat_index] . ', ' . $first_row[$long_index];
    fwrite($output_file, "<station id=\"$station_id\" name=\"$station_name\" geocode=\"$station_geocode\">\n");
    rewind($input_file);
    fgetcsv($input_file);
    while (($line = fgets($input_file)) !== false) {
        $data = str_getcsv($line, ',');
        $ts = $data[1];
        $nox = $data[2];
        $no2 = $data[3];
        $no = $data[4];
        fwrite($output_file, "<rec ts=\"$ts\" nox=\"$nox\" no2=\"$no2\" no=\"$no\" />\n");
    }
    fwrite($output_file, "</station>\n");
    fclose($input_file);
    fclose($output_file);
}
?>

