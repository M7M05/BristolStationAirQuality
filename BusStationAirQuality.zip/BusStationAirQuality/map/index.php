<!DOCTYPE html>
<html>
<head>
  <title>Station Map</title>
  <style>
    #map {
      height: 400px;
    }
  </style>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCpq08a7wAKn8HoXvefKnejBb-hvICYDJo"></script>
  <script>
    function initMap() {
      var map = new google.maps.Map(document.getElementById('map'), {
        center: {lat: 51.5074, lng: -2.5739},
        zoom: 10
      });
      var filenames = [
        'data-188.xml',
        'data-203.xml',
        'data-206.xml',
        'data-209.xml',
        'data-213.xml',
        'data-215.xml',
        'data-228.xml',
        'data-270.xml',
        'data-271.xml',
        'data-375.xml',
        'data-395.xml',
        'data-452.xml',
        'data-447.xml',
        'data-459.xml',
        'data-463.xml',
        'data-481.xml',
        'data-500.xml',
        'data-501.xml',
        'data-672.xml'
      ];

      filenames.forEach(function(filename) {
        var url = 'http://localhost/BusStationAirQuality/' + filename; //<<< Location is relitive to system.
        var xhr = new XMLHttpRequest();
        xhr.open('GET', url, true);
        xhr.onreadystatechange = function() {
          if (xhr.readyState === 4 && xhr.status === 200) {
            var xmlData = xhr.responseXML;
            var stationId = xmlData.querySelector('station').getAttribute('id');
            var stationName = xmlData.querySelector('station').getAttribute('name');
            var geocode = xmlData.querySelector('station').getAttribute('geocode').split(',');
            var latLng = new google.maps.LatLng(parseFloat(geocode[0]), parseFloat(geocode[1]));
            var marker = new google.maps.Marker({
              position: latLng,
              map: map,
              title: stationName
            });
            var infoWindow = new google.maps.InfoWindow({
              content: 'Station ID: ' + stationId + '<br>' + 'Station Name: ' + stationName
            });
            marker.addListener('click', function() {
              infoWindow.open(map, marker);
            });
          }
        };
        xhr.send();
      });
    }
  </script>
</head>
<body>
  <div id="map"></div>
  <script>
    initMap();
  </script>
</body>
</html>
